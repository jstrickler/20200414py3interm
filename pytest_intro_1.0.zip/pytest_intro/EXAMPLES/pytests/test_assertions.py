#!/usr/bin/env python
import pytest

def test_two_plus_two_equals_four():
    assert 2 + 2 == 4
